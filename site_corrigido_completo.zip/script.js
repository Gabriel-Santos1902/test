document.addEventListener('DOMContentLoaded', function () {
  const links = document.querySelectorAll('a[target="_blank"]');

  links.forEach(link => {
    link.addEventListener('click', function () {
      console.log(`Abrindo: ${link.href}`);
    });
  });

  const btnOrcamento = document.querySelector('.btn');
  if (btnOrcamento) {
    btnOrcamento.addEventListener('click', () => {
      window.open('orcamento.html', '_blank');
    });
  }

  const form = document.getElementById("formOrcamento");
  const msg = document.getElementById("mensagemConfirmacao");

  if (form) {
    form.addEventListener("submit", function(e) {
      e.preventDefault();
      const email = document.getElementById("email").value;
      msg.innerText = `Obrigado! Em breve entraremos em contato pelo e-mail: ${email}`;
      msg.style.display = "block";
      form.reset();
    });
  }
});
